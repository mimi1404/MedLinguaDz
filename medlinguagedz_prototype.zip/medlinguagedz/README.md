# MedlinguageDZ - Prototype

This is a front-end prototype for MedlinguageDZ, a digital platform for learning Medical English in Algeria.

## Pages
- `index.html`: Homepage
- `lesson.html`: Sample medical English lesson
- `quiz.html`: Example multiple-choice quiz
- `certificate.html`: Certificate preview (dummy)

## How to Use
1. Clone or download this repository
2. Open `index.html` in a browser
3. Navigate through links to view prototype

## Goal
This prototype is part of a startup project under the 1275 Ministry Decree in Algeria.

## Author
[Your Name], Technical English Student – 2025
